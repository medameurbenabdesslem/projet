<?php

namespace App\DataFixtures;

use App\Entity\Article;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class ArticleFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);
        for ($i = 0; $i <= 30; $i++){
            $a1= new Article();
            $a1->setMarque('zara');
            $a1->setCouleur('noire');
            $a1->setTissu('modelepontalon');
            $a1->setPrix('120.000');
            $a1->setImage('image.jpg');
            $a1->setQuantite('50');
            $a1->setCategorie($manager->merge($this->getReference('category-pontalon')));

            $a2= new Article();
            $a2->setMarque('bershka');
            $a2->setCouleur('blanc');
            $a2->setTissu('modelechemise');
            $a2->setPrix('85.000');
            $a2->setImage('image2.jpg');
            $a2->setQuantite('25');
            $a2->setCategorie($manager->merge($this->getReference('category-chemise')));

            $a3= new Article();
            $a3->setMarque('pull&bear');
            $a3->setCouleur('bleu');
            $a3->setTissu('modelejean');
            $a3->setPrix('115.000');
            $a3->setImage('image3.jpg');
            $a3->setQuantite('25');
            $a3->setCategorie($manager->merge($this->getReference('category-jean')));

            $a4= new Article();
            $a4->setMarque('pull&bear');
            $a4->setCouleur('marron');
            $a4->setTissu('modeleveste');
            $a4->setPrix('200.000');
            $a4->setImage('image4.jpg');
            $a4->setQuantite('30');
            $a4->setCategorie($manager->merge($this->getReference('category-veste')));

            $a5= new Article();
            $a5->setMarque('pull&bear');
            $a5->setCouleur('jaune');
            $a5->setTissu('modelepull');
            $a5->setPrix('95.000');
            $a5->setImage('image4.jpg');
            $a5->setQuantite('85');
            $a5->setCategorie($manager->merge($this->getReference('category-pull')));
           
        $manager->persist($a1);
        $manager->persist($a2);
        $manager->persist($a3);
        $manager->persist($a4);
        $manager->persist($a5);
      

    }

    $manager->flush();


        
    }
     /**
     * @return array
     */
    public function getDependencies(): array
    {
        return [
            CategorieFixtures::class,
        ];
    }
}
