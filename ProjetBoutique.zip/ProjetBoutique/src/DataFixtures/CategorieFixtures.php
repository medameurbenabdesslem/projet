<?php

namespace App\DataFixtures;

use App\Entity\Categorie;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class CategorieFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);


        $designCategory1 = new Categorie();
        $designCategory1->setNom('T-shirt');

        $designCategory2 = new Categorie();
        $designCategory2->setNom('jean');

        $designCategory3 = new Categorie();
        $designCategory3->setNom('veste');

        $designCategory4 = new Categorie();
        $designCategory4->setNom('pontalon');

        $designCategory5 = new Categorie();
        $designCategory5->setNom('Chemise');

        $manager->persist($designCategory1);
        $manager->persist($designCategory2);
        $manager->persist($designCategory3);
        $manager->persist($designCategory4);
        $manager->persist($designCategory5);

        $manager->flush();

        $this->addReference('category-pull', $designCategory1);
        $this->addReference('category-jean', $designCategory2);
        $this->addReference('category-veste', $designCategory3);
        $this->addReference('category-pontalon', $designCategory4);
        $this->addReference('category-chemise', $designCategory5);


        
    }
}
